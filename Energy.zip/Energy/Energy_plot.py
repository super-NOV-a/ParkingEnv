import numpy as np
import plotly.graph_objects as go

def parking_energy(x, y, yaw, cx, cy, cyaw):
    c1 = 10
    c2 = 20
    R_min = 5

    rou = np.sqrt((x - cx)**2 + (y - cy)**2)
    theta_l = np.arctan2(y - cy, x - cx)
    delta_theta = yaw - cyaw

    # 安全 tan 值
    tan_delta_half = np.tan(delta_theta / 2)
    tan_theta_l = np.tan(theta_l)

    # 避免除以零：使用 np.where 做安全除法
    safe_tan_theta_l = np.where(tan_theta_l == 0, np.inf, tan_theta_l)

    distance_1 = rou * np.cos(theta_l) * (np.tan(theta_l) - tan_delta_half)
    distance_2 = rou * np.sin(theta_l) * (1 - tan_delta_half / safe_tan_theta_l)

    # 使用 np.where 替代 if-else
    difference_distance = np.where(
        np.sin(theta_l) == 0,
        distance_1,
        np.where(
            np.cos(theta_l) == 0,
            distance_2,
            (distance_1 + distance_2) / 2
        )
    )

    driving_distance = np.abs(rou * difference_distance)

    position_distance = rou + np.abs(delta_theta) * 1
    energy_distance = c1 / (1 + position_distance) * np.cos(delta_theta)
    # energy_distance = c1 / (1 + position_distance)

    R1 = rou / 2 * np.sin(delta_theta / 2)
    R2 = rou / 2 * np.sin(theta_l)
    R_difference = (R1**2 + R2**2) - R_min**2

    k = 20
    energy_difference = c2 / (1 + driving_distance) * (1 / (1 + np.exp(-k * (R_difference - 1)))) * np.cos(delta_theta)



    return energy_distance * 9 + energy_difference


def plot_energy(all_nodes, initial_point = [0, 0, 0]):


    xs = np.array([node.x for node in all_nodes])
    ys = np.array([node.y for node in all_nodes])
    yaws = np.array([node.yaw for node in all_nodes])

    # 设置范围：最小值 - 2 到最大值 + 2
    padding = 2.0
    padding_yaw = np.pi
    x_range = (xs.min() - padding, xs.max() + padding)
    y_range = (ys.min() - padding, ys.max() + padding)
    z_range = (yaws.min() - padding_yaw, yaws.max() + padding_yaw)

    resolution = 50  # 网格分辨率
    sigma = 1.0  # 高斯分布宽度

    # ==========================
    # 创建网格
    # ==========================
    x = np.linspace(*x_range, 100)
    y = np.linspace(*y_range, resolution)
    z = np.linspace(*z_range, resolution)
    X, Y, Z = np.meshgrid(x, y, z)

    energy = np.zeros_like(X)

    for node in all_nodes:
        if node.depth == 0:
            weight = 3
        elif node.depth < 3:
            weight = 1 * (0.7 ** node.depth)
        else:
            weight = 1 * (0.5 ** node.depth)

        # weight = 1
        energy += weight * parking_energy(X, Y, Z, node.x, node.y, node.yaw)


    fig = go.Figure()

    # --------------------------
    # 1. 等值面（Isosurface）
    # --------------------------

    energy_min = energy.min()
    energy_max = energy.max()

    fig.add_volume(
        x=X.flatten(),
        y=Y.flatten(),
        z=Z.flatten(),
        value=energy.flatten(),
        isomin=energy_min,
        isomax=energy_max,
        opacity=0.3,
        surface_count=15,
        colorscale='Viridis',
        caps=dict(x_show=False, y_show=False, z_show=False),
        name='Energy Volume',
        colorbar=dict(title="Energy", tickformat=".2f")
    )

    fig.add_trace(go.Scatter3d(
        x=[initial_point[0]],
        y=[initial_point[1]],
        z=[initial_point[2]],
        mode='markers',
        marker=dict(size=3, color='red'),
        name='Initial Point'
    ))



    # # --------------------------
    # # 3. 动态切片（滑块控制）
    # # --------------------------
    # # 添加多个切片（例如每 5 层一个）
    # for i in range(0, len(z), 5):
    #     fig.add_trace(go.Surface(
    #         z=np.full_like(X[:, :, i], z[i]),
    #         surfacecolor=energy[:, :, i],
    #         colorscale='Viridis',
    #         showscale=True if i == 0 else False,
    #         visible=False,  # 默认隐藏
    #         name=f'z={z[i]:.2f}'
    #     ))

    # # 显示第一个切片
    # fig.data[1].visible = True

    # --------------------------
    # 4. 滑块控制
    # --------------------------
    steps = []
    for i in range(1, len(fig.data)):
        step = dict(
            method="update",
            args=[{"visible": [False] * len(fig.data)}],
            label=f"z={z[(i-1)*5]:.2f}" if i < len(z)//5 else f"z={z[-1]:.2f}"
        )
        step["args"][0]["visible"][0] = True  # 等值面始终可见
        step["args"][0]["visible"][i] = True  # 当前切片可见
        steps.append(step)

    sliders = [dict(
        active=0,
        currentvalue={"prefix": "Z-slice: "},
        pad={"t": 50},
        steps=steps
    )]

    fig.update_layout(sliders=sliders)

    # --------------------------
    # 5. 动画按钮（可选）
    # --------------------------
    fig.update_layout(
        updatemenus=[dict(
            type="buttons",
            buttons=[dict(label="Play", method="animate", args=[None])]
        )]
    )

    # --------------------------
    # 6. 图像布局
    # --------------------------
    fig.update_layout(
        scene=dict(
            xaxis_title='X',
            yaxis_title='Y',
            zaxis_title='Z'
        ),
        title='3D Energy Volume with Isosurface and Dynamic Slicing',
        margin=dict(l=0, r=0, b=0, t=40)
    )

    # ==========================
    # 显示图形
    # ==========================
    fig.show()  