import json
import os

def save_nodes_to_json(all_nodes, output_path="nodes.json"):
    nodes_data = []
    for node in all_nodes:
        node_info = {
            "x": node.x,
            "y": node.y,
            "yaw": node.yaw,
            "depth": node.depth
        }
        nodes_data.append(node_info)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(nodes_data, f, indent=4, ensure_ascii=False)

    print(f"✅ 所有节点信息已保存到：{output_path}, 一共{len(all_nodes)} 个节点")




from types import SimpleNamespace
def load_nodes_from_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        nodes_data = json.load(f)

    all_nodes = []
    for node_info in nodes_data:
        node = SimpleNamespace(
            x=node_info['x'],
            y=node_info['y'],
            yaw=node_info['yaw'],
            depth=node_info['depth']
        )
        all_nodes.append(node)

    print(f"✅ 已从 {json_path} 加载 {len(all_nodes)} 个节点")
    return all_nodes