import numpy as np
import matplotlib.pyplot as plt
from collections import deque
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle
import cv2
import plotly.graph_objects as go
from Energy_plot import plot_energy

class VehicleState:
    def __init__(self, x=0.0, y=0.0, yaw=0.0, v=0.0, delta=0.0, depth=0, parent=None):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v  # 速度
        self.delta = delta  # 转向角
        self.depth = depth
        self.parent = parent
        self.children = []
        
    
    def add_child(self, child_state):
        self.children.append(child_state)

class TrajectoryTreeGenerator:
    def __init__(self, L=3.5, dt=0.1, internal_steps=20, collision_check_steps=50, vehicle_state_init=[0,0,0], check_polygon=False):
        
        self.vehicle_state_init = vehicle_state_init
        self.L = L  # 车辆轴距
        self.dt = dt  # 时间步长
        self.internal_steps = internal_steps  # 内部积分步数
        self.internal_dt = dt / internal_steps  # 内部时间步长
        self.collision_check_steps = collision_check_steps  # 碰撞检测的轨迹点数
        self.root = VehicleState(x=vehicle_state_init[0], y=vehicle_state_init[1], yaw=vehicle_state_init[2])
        self.check_polygon = check_polygon
        
        # # 定义障碍物 (中心坐标, 边长)
        self.obstacles = [
            {'center': (10, 10), 'size': 3},
            {'center': (10, -2), 'size': 5},
            {'center': (-2, 1), 'size': 2},
            {'center': (-2, -1), 'size': 2}
            
        ]
                # 定义障碍物 (中心坐标, 边长)
        # self.obstacles = [ ]
    
    def check_collision_with_point(self, x, y):
        """检查单个点是否与任何障碍物碰撞"""
        for obs in self.obstacles:
            cx, cy = obs['center']
            size = obs['size']
            if (cx - size/2 <= x <= cx + size/2) and (cy - size/2 <= y <= cy + size/2):
                return True
        return False
    
    def check_trajectory_segment_collision(self, start_state, end_state):
        """检查轨迹段是否与障碍物碰撞"""
        # 获取轨迹点
        points = self.get_trajectory_points(start_state, end_state, self.collision_check_steps)
        
        # 检查每个点
        for point in points:
            if self.check_polygon == False:
                if self.check_collision_with_point(point[0], point[1]):
                    return True
            else:
                vehicle_x_min = -1.1
                vehicle_x_max = 3.925
                vehicle_y_min = -1.1
                vehicle_y_max = 1.1 
                pixel_to_meter_ratio = 0.025
                meter_to_pixel = lambda meters: int(meters / pixel_to_meter_ratio)
                crop_l = 0.3 ##0.3m
                crop_w = 0.2 ##0.2m
                ego_x_px = 800
                ego_y_px = 800
                rear_hang = 1.025
                rect_with_corner_cropped = np.array([
                    [meter_to_pixel(-rear_hang + crop_l)+ego_x_px, meter_to_pixel(-1)+ego_y_px],     # bottom edge, left (after cropping left bottom corner)
                    [meter_to_pixel(vehicle_x_max - crop_l)+ego_x_px, meter_to_pixel(-1)+ego_y_px],  # bottom edge, right (after cropping right bottom corner)
                    [meter_to_pixel(vehicle_x_max)+ego_x_px, meter_to_pixel(-1 + crop_w)+ego_y_px],  # right edge, bottom (after cropping right bottom corner)
                    [meter_to_pixel(vehicle_x_max)+ego_x_px,  meter_to_pixel(1 - crop_w)+ego_y_px],  # right edge, top (after cropping right top corner)
                    [meter_to_pixel(vehicle_x_max - crop_l)+ego_x_px,  meter_to_pixel(1)+ego_y_px],  # top edge, right (after cropping right top corner)
                    [meter_to_pixel(-rear_hang + crop_l)+ego_x_px, meter_to_pixel(1)+ego_y_px],      # top edge, left (after cropping left top corner)
                    [meter_to_pixel(-rear_hang)+ego_x_px,  meter_to_pixel(1 - crop_w)+ego_y_px],     # left edge, top (after cropping left top corner)
                    [meter_to_pixel(-rear_hang)+ego_x_px, meter_to_pixel(-1 + crop_w)+ego_y_px]      # left edge, bottom (after cropping left bottom corner)
                ])
                pixel_to_meter_ratio = 0.025 #0.05 # 0.025  # 1 pixel = 0.025 meters
                full_image_width_m = 40
                full_image_height_m = 40
                full_image_width_px = int(full_image_width_m / pixel_to_meter_ratio) # 1600 pixels
                full_image_height_px = int(full_image_height_m / pixel_to_meter_ratio) # 1600 pixels
                
                # Create a blank grayscale image (uint8: values 0 to 255)
                full_image = np.full((full_image_height_px, full_image_width_px), 0, dtype=np.uint8)  # black background

                # meter_to_pixel(goal_x)+ego_x_px, -meter_to_pixel(goal_y)+ego_y_px
                collision = check_polygon_contains_other_color(full_image, rect_with_corner_cropped, 75, target_color=170)
                if collision == True:
                    return True
        return False
    
    def check_full_trajectory_collision(self, state):
        """检查从根节点到当前节点的整个轨迹是否发生碰撞"""
        # 回溯整个轨迹路径
        path = []
        current = state
        while current.parent is not None:
            path.append((current.parent, current))
            current = current.parent
        
        # 从根节点开始检查每个轨迹段
        for start, end in reversed(path):
            if self.check_trajectory_segment_collision(start, end):
                return True
        
        return False
    
    def get_trajectory_points(self, start_state, end_state, num_points):
        """获取两点之间的轨迹点"""
        points = [(start_state.x, start_state.y)]
        L = self.L
        
        # 使用起始状态的位置和航向
        x, y, yaw = start_state.x, start_state.y, start_state.yaw
        
        # 使用结束状态的速度和转向角（即该时间步长内使用的控制输入）
        v = end_state.v
        delta = end_state.delta
        
        # 计算时间步长 (假设整个轨迹段时间为dt)
        dt = self.dt / num_points
        
        # 模拟轨迹
        for _ in range(num_points):
            points.append((x, y))
            
            # 更新航向
            yaw += (v / L) * np.tan(delta) * dt
            
            # 更新位置
            x += v * np.cos(yaw) * dt
            y += v * np.sin(yaw) * dt
        
        # 添加终点
        points.append((x, y))
        return points
    
    def generate(self, total_time, velocity_samples, delta_samples):
        """
        生成轨迹树
        :param total_time: 总时间(s)
        :param velocity_samples: 速度采样列表(m/s)
        :param delta_samples: 转向角采样列表(弧度)
        """
        self.all_nodes = [self.root]
        steps = int(total_time / self.dt)
        current_depth = 0
        queue = deque([self.root])
        
        step = 0
        while step < steps:
            next_depth = current_depth + 1
            next_queue = deque()
            
            while queue:
                current_node = queue.popleft()
                
                for v in velocity_samples:
                    for delta in delta_samples:
                        # 生成子节点
                        child_state = self.integrate_state(
                            current_node, 
                            v,
                            delta,
                            next_depth
                        )

                        # if current_node.parent != None:
                        #     if child_state.x == current_node.parent.x and child_state.y == current_node.parent.y:
                        #         continue  # 如果重合，则跳过这个子节点

                        # 检查子节点是否与父节点重合（基于阈值）
                        if current_node.parent is not None:
                            distance_to_parent = np.sqrt((child_state.x - current_node.parent.x)**2 + (child_state.y - current_node.parent.y)**2)
                            if distance_to_parent < 0.5:  # 阈值为0.1
                                continue  # 如果距离小于阈值，则跳过这个子节点

                        skip_flag = False
                        for existing_node in self.all_nodes:
                            distance_to_existing_node = np.sqrt((child_state.x - existing_node.x)**2 + (child_state.y - existing_node.y)**2)
                            if distance_to_existing_node < 1 and np.abs(child_state.yaw - existing_node.yaw) < 0.1:
                                skip_flag = True
                                break  # 如果与任何现有节点的距离小于阈值，则跳过这个子节
                        if skip_flag:
                            continue
                        
                        # 检查整个轨迹（从根节点到当前节点）是否安全
                        collision = self.check_full_trajectory_collision(child_state)
                        
                        # 如果没有碰撞，则添加到树中
                        if not collision:
                            current_node.add_child(child_state)
                            self.all_nodes.append(child_state)
                            next_queue.append(child_state)
            
            queue = next_queue
            current_depth = next_depth

            # if len(self.all_nodes) < 20:
            #     steps += 1  # 增加一次循环
            
            step += 1  # 增加一次循环
            
    def integrate_state(self, current_state, v, delta, next_depth):
        """
        使用更精确的积分方法计算下一状态
        :param current_state: 当前状态
        :param v: 速度(m/s)
        :param delta: 转向角(弧度)
        :param next_depth: 下一层级
        :return: 新状态节点
        """
        # 从当前状态获取初始位置和航向
        x, y, yaw = current_state.x, current_state.y, current_state.yaw
        
        # 在每个小时间步内积分
        for _ in range(self.internal_steps):
            # 更新航向
            yaw += (v / self.L) * np.tan(delta) * self.internal_dt
            
            # 更新位置
            x += v * np.cos(yaw) * self.internal_dt
            y += v * np.sin(yaw) * self.internal_dt
        
        # 创建新状态节点
        return VehicleState(
            x=x, y=y, yaw=yaw, v=v, delta=delta,
            depth=next_depth, parent=current_state
        )

def plot_trajectory_tree(generator, all_nodes, max_depth, vehicle_state, vehicle_state_init):
    plt.figure(figsize=(12, 10))
    colors = plt.cm.jet(np.linspace(0, 1, max_depth + 1))
    
    plot_energy(all_nodes, vehicle_state)

    # 绘制障碍物
    for obs in generator.obstacles:
        cx, cy = obs['center']
        size = obs['size']
        plt.gca().add_patch(Rectangle(
            (cx-size/2, cy-size/2), size, size,
            facecolor='red', alpha=0.5
        ))
    
    # 绘制轨迹
    for node in all_nodes:
        if node.parent is not None:
            depth = node.depth
            color = colors[depth]
            
            # 获取轨迹点
            points = generator.get_trajectory_points(node.parent, node, 20)
            # 绘制轨迹线
            plt.plot(
                [p[0] for p in points],
                [p[1] for p in points],
                color=color, linewidth=1.5 - depth*0.1
            )
            # 在父节点位置添加标记
            plt.plot(node.parent.x, node.parent.y, 'ko', markersize=3)

        # 绘制箭头表示航向
        arrow_length = 0.5  # 箭头长度
        dx = arrow_length * np.cos(node.yaw)
        dy = arrow_length * np.sin(node.yaw)
        plt.arrow(node.x, node.y, dx, dy, head_width=0.2, head_length=0.2, fc='#800080', ec='#800080')

        # 计算并显示每个节点的 difference_distance
        target_states = [node.x, node.y, node.yaw]
        [distance, driving_distance] = difference_distance(target_states, vehicle_state)
        plt.text(node.x, node.y, f'{distance:.2f}', color='red', fontsize=8, ha='right')
        plt.text(node.x, node.y-0.3, f'{driving_distance:.2f}', color='blue', fontsize=8, ha='right')

        # # 计算并显示每个节点的 difference_distance
        # target_states = [node.x, node.y, node.yaw]
        # [distance, driving_distance] = difference_distance(target_states, vehicle_state_init)
        # plt.text(node.x, node.y-0.3, f'{distance:.2f}', color='blue', fontsize=8, ha='right')
    
    # 添加颜色条
    ax = plt.gca()
    sm = plt.cm.ScalarMappable(cmap=plt.cm.jet, norm=plt.Normalize(0, max_depth))
    sm.set_array([])
    fig = plt.gcf()
    cbar = fig.colorbar(sm, ax=ax, label='Time Level')
    cbar.set_ticks(np.arange(0, max_depth + 1))
    
    # 绘制起点
    plt.plot(all_nodes[0].x, all_nodes[0].y, 'go', markersize=10, label='Start')
    plt.plot(vehicle_state[0], vehicle_state[1], 'ro', markersize=10, label='Vehicle')
    plt.arrow(vehicle_state[0], vehicle_state[1], 0.5* np.cos(vehicle_state[2]), 0.5* np.sin(vehicle_state[2]), 
              head_width=0.2, head_length=0.2, fc="#F00000", ec="#FF0000")
    
    plt.xlabel('X (m)')
    plt.ylabel('Y (m)')
    plt.title('Trajectory Tree with Delta and V as Inputs')
    plt.grid(True)
    plt.axis('equal')
    plt.legend()

    # 调整图片大小和位置
    fig = plt.gcf()
    fig.set_size_inches(8, 6)  # 设置窗口大小为 8x6 英寸
    manager = plt.get_current_fig_manager()
    manager.window.wm_geometry("+800+100")
    plt.show()



def difference_distance(target_states, vehicle_state):
    
    x, y, yaw = target_states[0], target_states[1], target_states[2]
    base_x, base_y, base_yaw = vehicle_state[0], vehicle_state[1], vehicle_state[2]

    rou = np.sqrt((x - base_x)**2 + (y - base_y)**2)
    theta_l  = np.atan2((y - base_y),(x - base_x))
    delta_theta = yaw - base_yaw

    # 调整 theta_l 的范围到 0 到 pi
    # if theta_l < 0:
    #     theta_l += 2 * np.pi
    # if theta_l > np.pi:
    #     theta_l -= 2 * np.pi

    # 判断象限并调整 theta_l 的值
    # if (x - base_x) > 0 and (y - base_y) > 0:  # 第一象限
    #     pass
    # elif (x - base_x) < 0 and (y - base_y) > 0:  # 第二象限
    #     pass
    # elif (x - base_x) < 0 and (y - base_y) < 0:  # 第三象限
    #     theta_l += np.pi
    # elif (x - base_x) > 0 and (y - base_y) < 0:  # 第四象限
    #     theta_l += np.pi

    distance_1 = rou * np.cos(theta_l) * (np.tan(theta_l) - np.tan(delta_theta/2))
    distance_2 = rou * np.sin(theta_l) * (1 - np.tan(delta_theta/2) / np.tan(theta_l))

    # 处理特殊情况
    if np.sin(theta_l) == 0:
        distance = distance_1
    elif np.cos(theta_l) == 0:
        distance = distance_2
    else:
        distance = (distance_1 + distance_2) / 2

    driving_distance =  rou * distance
    return [distance, driving_distance]



def check_polygon_contains_other_color(canvas, polygon, self_color, target_color=None):
    """
    Check if a polygon region on the canvas contains any pixel of color `target_color`
    other than `self_color`.

    :param canvas: 2D (grayscale) or 3D (RGB) image
    :param polygon: Nx2 NumPy array of polygon vertices (int pixel coordinates)
    :param self_color: Color of the polygon itself (e.g., 255 for ego)
    :param target_color: If None, checks for any color != self_color
    :return: True if any pixel in polygon area has other color, else False
    """
    # Create a binary mask of the polygon
    mask = np.zeros(canvas.shape[:2], dtype=np.uint8)
    polygon_int = np.round(polygon).astype(np.int32)
    cv2.fillPoly(mask, [polygon_int], 1)

    # Masked region from canvas
    if len(canvas.shape) == 2:  # Grayscale
        masked_pixels = canvas[mask == 1]
        if target_color is not None:
            return np.any(masked_pixels == target_color)
        else:
            return np.any(masked_pixels != self_color)

    elif len(canvas.shape) == 3:  # RGB
        masked_pixels = canvas[mask == 1]
        if target_color is not None:
            return np.any(np.all(masked_pixels == target_color, axis=1))
        else:
            return np.any(np.any(masked_pixels != self_color, axis=1))
    else:
        raise ValueError("Unsupported canvas format.")


if __name__ == "__main__":
    total_time = 3  # 总时间(s)W
    dt = 1.0        # 时间步长(s)
    
    # 速度采样 (m/s)
    velocity_samples = [-4.0, 4.0]
    # velocity_samples = [4.0]

    actual_vehicle_state = [0,0,0]
    vehicle_state_init = [0,0,0]

    # 转向角采样 (弧度) - 使用度数更直观，转换为弧度
    delta_degrees = [-30, 0, 30]  # 角度值
    delta_samples = np.deg2rad(delta_degrees)  # 转换为弧度

    generator = TrajectoryTreeGenerator(dt=dt, collision_check_steps=100, vehicle_state_init=vehicle_state_init,check_polygon=False)
    generator.generate(total_time, velocity_samples, delta_samples)
    
    max_depth = max(node.depth for node in generator.all_nodes)
    safe_nodes = len(generator.all_nodes)
    print(f"Generated {safe_nodes} safe nodes after pruning")
    print(f"Max depth: {max_depth}")
    
    plot_trajectory_tree(generator, generator.all_nodes, max_depth, actual_vehicle_state, vehicle_state_init)