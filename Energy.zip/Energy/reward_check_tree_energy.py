import json, os 
import matplotlib.pyplot as plt
import math
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from matplotlib.ticker import MultipleLocator
import cv2
from Energy_plot import plot_energy
from Energy_plot import parking_energy
from Json_energy_load import save_nodes_to_json
from Json_energy_load import load_nodes_from_json

# from Trajecotry_generator_demo import TrajectoryTreeGenerator
 

from collections import deque
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle

from tqdm import tqdm
# import gym
# from gym import spaces

from scipy.interpolate import interp1d
 
import time

class VehicleState:
    def __init__(self, x=0.0, y=0.0, yaw=0.0, v=0.0, delta=0.0, depth=0, parent=None):
        self.x = x
        self.y = y
        self.yaw = yaw
        self.v = v  # 速度
        self.delta = delta  # 转向角
        self.depth = depth
        self.parent = parent
        self.children = []
        
    
    def add_child(self, child_state):
        self.children.append(child_state)

class TrajectoryTreeGenerator:
    def __init__(self, L=3, dt=0.1, internal_steps=10, collision_check_steps=20, vehicle_state_init=[0,0,0], check_polygon=False, 
                 full_image = np.full((1600, 1600), 0, dtype=np.uint8)):
        
        self.start = True
        self.vehicle_state_init = vehicle_state_init
        self.L = L  # 车辆轴距
        self.dt = dt  # 时间步长
        self.internal_steps = internal_steps  # 内部积分步数
        self.internal_dt = dt / internal_steps  # 内部时间步长
        self.collision_check_steps = collision_check_steps  # 碰撞检测的轨迹点数
        self.root = VehicleState(x=vehicle_state_init[0], y=vehicle_state_init[1], yaw=vehicle_state_init[2])
        self.check_polygon = check_polygon
        self.full_image = full_image
        # 定义障碍物 (中心坐标, 边长)
        self.obstacles = []
    
    def check_collision_with_point(self, x, y):
        """检查单个点是否与任何障碍物碰撞"""
        for obs in self.obstacles:
            cx, cy = obs['center']
            size = obs['size']
            if (cx - size/2 <= x <= cx + size/2) and (cy - size/2 <= y <= cy + size/2):
                return True
        return False
    
    def check_trajectory_segment_collision(self, start_state, end_state):
        """检查轨迹段是否与障碍物碰撞"""
        # 获取轨迹点
        points = self.get_trajectory_points(start_state, end_state, self.collision_check_steps)
        
        # 检查每个点
        for point in points:
            if self.check_polygon == False:
                if self.check_collision_with_point(point[0], point[1]):
                    return True
            else:
                # meter_to_pixel(goal_x)+ego_x_px, -meter_to_pixel(goal_y)+ego_y_px
                vehicle = Vehicle( 3,       0.925,      1.025,   2.0)
                temp = vehicle.create_polygon_vehicle(point[0], point[1], point[2])
                target_points = []
                for ele in temp[0:8]:
                    target_points.append([meter_to_pixel(ele[0])+ego_x_px, -meter_to_pixel(ele[1])+ego_y_px])
                target_points = np.array(target_points).reshape((-1,1,2))   

                collision = check_polygon_contains_other_color(self.full_image, target_points, 75, target_color=170)
                if collision == True:
                    return True
        return False
    
    def check_full_trajectory_collision(self, state):
        """检查从根节点到当前节点的整个轨迹是否发生碰撞"""
        # 回溯整个轨迹路径
        path = []
        current = state
        while current.parent is not None:
            path.append((current.parent, current))
            current = current.parent
        
        # 从根节点开始检查每个轨迹段
        for start, end in reversed(path):
            if self.check_trajectory_segment_collision(start, end):
                return True
        
        return False
    
    def get_trajectory_points(self, start_state, end_state, num_points):
        """获取两点之间的轨迹点"""
        points = [(start_state.x, start_state.y, start_state.yaw)]
        L = self.L
        
        # 使用起始状态的位置和航向
        x, y, yaw = start_state.x, start_state.y, start_state.yaw
        
        # 使用结束状态的速度和转向角（即该时间步长内使用的控制输入）
        v = end_state.v
        delta = end_state.delta
        
        # 计算时间步长 (假设整个轨迹段时间为dt)
        dt = self.dt / num_points
        
        # 模拟轨迹
        for _ in range(num_points):
            points.append((x, y, yaw))
            
            # 更新航向
            yaw += (v / L) * np.tan(delta) * dt
            
            # 更新位置
            x += v * np.cos(yaw) * dt
            y += v * np.sin(yaw) * dt
        
        # 添加终点
        points.append((x, y, yaw))
        return points
    
    def generate(self, total_time, velocity_samples, delta_samples):
        """
        生成轨迹树
        :param total_time: 总时间(s)
        :param velocity_samples: 速度采样列表(m/s)
        :param delta_samples: 转向角采样列表(弧度)
        """
        self.all_nodes = [self.root]
        steps = int(total_time / self.dt)
        current_depth = 0
        queue = deque([self.root])

        step = 0
        previous_node_count = 0
        while step < steps:
            next_depth = current_depth + 1
            next_queue = deque()
            if step <= 2:
                velocity_sample_ad = [v/2 for v in velocity_samples if v > 0]
            else:
                velocity_sample_ad = velocity_samples
                
            while queue:
                current_node = queue.popleft()
                
                for v in velocity_sample_ad:
                    for delta in delta_samples:
                        # 生成子节点
                        child_state = self.integrate_state(
                            current_node, 
                            v,
                            delta,
                            next_depth
                        )

                        # if current_node.parent != None:
                        #     if child_state.x == current_node.parent.x and child_state.y == current_node.parent.y:
                        #         continue  # 如果重合，则跳过这个子节点

                        # 检查子节点是否与父节点重合（基于阈值）
                        if current_node.parent is not None:
                            distance_to_parent = np.sqrt((child_state.x - current_node.parent.x)**2 + (child_state.y - current_node.parent.y)**2)
                            if distance_to_parent < 0.5:  # 阈值为0.1
                                continue  # 如果距离小于阈值，则跳过这个子节点

                        skip_flag = False
                        for existing_node in self.all_nodes:
                            distance_to_existing_node = np.sqrt((child_state.x - existing_node.x)**2 + (child_state.y - existing_node.y)**2)
                            if distance_to_existing_node < 1 and np.abs(child_state.yaw - existing_node.yaw) < 0.1:
                                skip_flag = True
                                break  # 如果与任何现有节点的距离小于阈值，则跳过这个子节
                        if skip_flag:
                            continue
                        
                        # 检查整个轨迹（从根节点到当前节点）是否安全
                        collision = self.check_full_trajectory_collision(child_state)
                        
                        # 如果没有碰撞，则添加到树中
                        if not collision:
                            current_node.add_child(child_state)
                            self.all_nodes.append(child_state)
                            next_queue.append(child_state)
            
            queue = next_queue
            current_depth = next_depth
            if step == steps - 1 and len(self.all_nodes) < 80:
                steps += 1 
            if len(self.all_nodes) > 100:
                break
            if step > 20:
                break
            if len(self.all_nodes) == previous_node_count:
                velocity_sample_ad = [v / 2 for v in velocity_sample_ad]
                velocity_samples = velocity_sample_ad
                print(f"step:{velocity_sample_ad}")
                steps += 1 
            else:
                previous_node_count = len(self.all_nodes)
            
            print(f"step:{step}, steps:{steps}")
            step += 1
    
    def integrate_state(self, current_state, v, delta, next_depth):
        """
        使用更精确的积分方法计算下一状态
        :param current_state: 当前状态
        :param v: 速度(m/s)
        :param delta: 转向角(弧度)
        :param next_depth: 下一层级
        :return: 新状态节点
        """
        # 从当前状态获取初始位置和航向
        x, y, yaw = current_state.x, current_state.y, current_state.yaw
        
        # 在每个小时间步内积分
        for _ in range(self.internal_steps):
            # 更新航向
            yaw += (v / self.L) * np.tan(delta) * self.internal_dt
            
            # 更新位置
            x += v * np.cos(yaw) * self.internal_dt
            y += v * np.sin(yaw) * self.internal_dt
        
        # 创建新状态节点
        return VehicleState(
            x=x, y=y, yaw=yaw, v=v, delta=delta,
            depth=next_depth, parent=current_state
        )

############################################################
def detect_reversal_points(x, y):
    """
    Identifies reversal points in a trajectory.
    Returns a list of indices where direction changes.
    """
    direction_changes = []
    for i in range(1, len(x) - 1):
        prev_dx = x[i] - x[i - 1]
        next_dx = x[i + 1] - x[i]
        prev_dy = y[i] - y[i - 1]
        next_dy = y[i + 1] - y[i]
        
        if np.sign(prev_dx) != np.sign(next_dx) or np.sign(prev_dy) != np.sign(next_dy):
            direction_changes.append(i)
    
    return direction_changes

def piecewise_interpolation(distances, values, fixed_distances, reversal_points):
    """
    Performs piecewise interpolation, ensuring that reversal points are explicitly included.
    """
    new_values = []
    prev_idx = 0
    
    for rp in reversal_points + [len(distances)]:  # Include last point
        # Perform interpolation for each segment separately
        segment_dist = distances[prev_idx:rp+1]
        segment_values = values[prev_idx:rp+1]
        segment_fixed_dist = fixed_distances[(fixed_distances >= segment_dist[0]) & (fixed_distances <= segment_dist[-1])]
        
        interp_func = interp1d(segment_dist, segment_values, kind="linear", fill_value="extrapolate")
        new_values.extend(interp_func(segment_fixed_dist))
        
        prev_idx = rp  # Move to the next segment
    
    return np.array(new_values)

def interpolate_path(path, fixed_interval=0.02):
    """
    Interpolates a path while preserving back-and-forth motion and avoiding angle wrapping issues.
    
    Parameters:
    - path: list of tuples [(x, y, theta, kappa), ...]
    - fixed_interval: float, desired fixed distance interval (meters)
    
    Returns:
    - interpolated_path: list of tuples [(x, y, theta, kappa), ...]
    """
    ##### Extract x, y, theta, and kappa
    np_path = np.array(path)
    x = np_path[:, 0]
    y = np_path[:, 1]
    theta = np_path[:, 2]
    kappa = np_path[:, 3]
    
    ##### Compute cumulative distances along the path
    distances = np.zeros(len(x))
    for i in range(1, len(x)):
        distances[i] = distances[i - 1] + np.sqrt((x[i] - x[i - 1])**2 + (y[i] - y[i - 1])**2)
    
    ##### Detect Reversal Points
    reversal_points = detect_reversal_points(x, y)
    
    ##### Generate fixed intervals
    fixed_distances = np.arange(0, distances[-1], fixed_interval)
    fixed_distances = np.clip(fixed_distances, distances[0], distances[-1])

    ##### Interpolate x, y, theta, and kappa using piecewise interpolation
    x_interp = piecewise_interpolation(distances, x, fixed_distances, reversal_points)
    y_interp = piecewise_interpolation(distances, y, fixed_distances, reversal_points)
    kappa_interp = piecewise_interpolation(distances, kappa, fixed_distances, reversal_points)
    
    ##### Interpolate theta using sin/cos method (handles wraparound)
    theta_interp_sin = piecewise_interpolation(distances, np.sin(theta), fixed_distances, reversal_points)
    theta_interp_cos = piecewise_interpolation(distances, np.cos(theta), fixed_distances, reversal_points)
    theta_interp = np.arctan2(theta_interp_sin, theta_interp_cos)

    ##### Combine interpolated results
    interpolated_path = list(zip(x_interp, y_interp, theta_interp, kappa_interp))
    return np.array(interpolated_path)
############################################################


def check_polygon_contains_other_color(canvas, polygon, self_color, target_color=None):
    """
    Check if a polygon region on the canvas contains any pixel of color `target_color`
    other than `self_color`.

    :param canvas: 2D (grayscale) or 3D (RGB) image
    :param polygon: Nx2 NumPy array of polygon vertices (int pixel coordinates)
    :param self_color: Color of the polygon itself (e.g., 255 for ego)
    :param target_color: If None, checks for any color != self_color
    :return: True if any pixel in polygon area has other color, else False
    """
    # Create a binary mask of the polygon
    mask = np.zeros(canvas.shape[:2], dtype=np.uint8)
    polygon_int = np.round(polygon).astype(np.int32)
    cv2.fillPoly(mask, [polygon_int], 1)

    # Masked region from canvas
    if len(canvas.shape) == 2:  # Grayscale
        masked_pixels = canvas[mask == 1]
        if target_color is not None:
            return np.any(masked_pixels == target_color)
        else:
            return np.any(masked_pixels != self_color)

    elif len(canvas.shape) == 3:  # RGB
        masked_pixels = canvas[mask == 1]
        if target_color is not None:
            return np.any(np.all(masked_pixels == target_color, axis=1))
        else:
            return np.any(np.any(masked_pixels != self_color, axis=1))
    else:
        raise ValueError("Unsupported canvas format.")

def filter_and_normalized_obstacles(obstacles, reference_pose, M=200, max_dist=10):
    """
    Convert obstacles from world to ego middle point coordinates, keep the nearest M points within the distance.
    Args:
        obstacles (np.array): (N,2) array of (x_w, y_w) world coordinates. Can be empty.
        reference_pose (tuple): (x_ego, y_ego, theta_ego) position and heading.
        M (int): Number of nearest points to keep. pad if less than M
    Returns:
        np.array: (M,8) array of nearest (x_e, y_e, pad_or_not, 0, 0, 0, 0, 0).
    """
    x_ego, y_ego, theta_ego = reference_pose
    if obstacles.shape[0] == 0:  # If no obstacles, return a padded array with mask = 0
        return np.full((M, 8), [0, 0, 0, 0, 0, 0, 0, 0])

    # Extract world coordinates
    x_w, y_w = obstacles[:, 0], obstacles[:, 1]

    # Convert to ego coordinates
    x_e = np.cos(theta_ego) * (x_w - x_ego) + np.sin(theta_ego) * (y_w - y_ego)
    y_e = -np.sin(theta_ego) * (x_w - x_ego) + np.cos(theta_ego) * (y_w - y_ego)

    ###### filter points that is outside of ego view
    # x_e_filter = []
    # y_e_filter = []

    # for x_e_i, y_e_i in zip(x_e, y_e):
    #     if abs(x_e_i) > max_dist or abs(y_e_i) > max_dist:
    #         continue 
    #     else:
    #         x_e_filter.append(x_e_i)
    #         y_e_filter.append(y_e_i)
    
    # Filter points within ego view
    valid_mask = (np.abs(x_e) <= max_dist) & (np.abs(y_e) <= max_dist)
    x_e_filter = x_e[valid_mask]
    y_e_filter = y_e[valid_mask]
    
    x_e_filter = np.array(x_e_filter, dtype=np.float32) ### at least change the dtype
    y_e_filter = np.array(y_e_filter, dtype=np.float32)
    
    ## Compute Euclidean distances
    distances = np.hypot(x_e_filter, y_e_filter)   
    angles = np.arctan2(y_e_filter, x_e_filter) 
    
    x_norm = np.clip(x_e_filter / max_dist, -1.0, 1.0)
    y_norm = np.clip(y_e_filter / max_dist, -1.0, 1.0)
    dist_norm = np.clip(distances / max_dist, 0.0, 1.0)
    sin_theta = np.sin(angles)
    cos_theta = np.cos(angles)
    
    inv_dist = 1.0/distances ### no need to normalize it as min_dist is great than 1 meter
    
    # Combine into (N', 6)
    features = np.stack((x_norm, y_norm, dist_norm, inv_dist, cos_theta, sin_theta), axis=1)

    ## Get indices of the M closest points
    M_ = min(M, len(x_e_filter))    # Adjust M if N < M
    nearest_indices = np.argsort(distances)[:M_]
    ## Select nearest obstacles
    nearest_obstacles = features[nearest_indices] ## np.column_stack((np.clip(x_e_filter[nearest_indices]/max_dist, -1.0, 1.0), np.clip(y_e_filter[nearest_indices]/max_dist, -1.0, 1.0)))


    # # Filter douplicates  ### the possibility of having duplicates is the dtype and clip operation
    # if len(nearest_obstacles) > 0:
    #     nearest_obstacles = np.unique(nearest_obstacles, axis=0)
        
        
    # Pad to M rows
    if len(nearest_obstacles) < M:
        padding = np.zeros((M - len(nearest_obstacles), 6), dtype=np.float32)
        nearest_obstacles = np.vstack([nearest_obstacles, padding])

    # Pad to (M, 8) to match expected input shape
    return np.pad(nearest_obstacles, pad_width=((0, 0), (0, 2)), mode='constant')
 

def get_obs(target_pos, target_heading, ego_state, obstacles_global, max_distance=10, max_obstacles=200, obs_shifted=False):
    ###### use the middle point of the ego as orign for the coordinate system
    ###### (N+2)*9 ==> ego_x, ego_y, cosine , sine, steering, step_distance, height, width, id 
    ego_x, ego_y, ego_theta, steering, speed = ego_state
    
    ###### ego middle point
    car_length = 4.95 
    car_width = 2.0
    L_m = 1.45  ### rear center to middle point
    ego_middle_x = ego_x + L_m * np.cos(ego_theta)
    ego_middle_y = ego_y + L_m * np.sin(ego_theta)
    
    tg_rela_xy = world_to_ego(target_pos, [ego_middle_x, ego_middle_y], ego_theta)   
    tg_rela_ang = target_heading - ego_theta
    
        
    x_target_norm = np.clip(tg_rela_xy[0]/max_distance, -1.0, 1.0)
    y_target_norm = np.clip(tg_rela_xy[1]/max_distance, -1.0, 1.0)
    vec_obs = np.array([[steering, speed, car_length/max_distance, car_width/max_distance, x_target_norm, y_target_norm, np.cos(tg_rela_ang), np.sin(tg_rela_ang)],
                        [x_target_norm, y_target_norm, np.cos(tg_rela_ang), np.sin(tg_rela_ang), 0.0, 0.0, 0.0, 0.0]], dtype=np.float32)
                                                            ### obstacles, reference_pose, M=200, max_dist=10
    obstacles_normalized = filter_and_normalized_obstacles(obstacles_global, [ego_middle_x, ego_middle_y, ego_theta])
    
    vec_obs = np.vstack([vec_obs, obstacles_normalized]) ### N+2 by 8
    return vec_obs 

def generate_shifted_polygon(point1, point2, shift_magnitude=0.1):
    # Calculate direction vectors
    dir1 = point1 / np.linalg.norm(point1)
    dir2 = point2 / np.linalg.norm(point2)
    # Generate shifted points
    shifted_point1 = point1 + shift_magnitude * dir1
    shifted_point2 = point2 + shift_magnitude * dir2
    # Form the polygon vertices
    polygon_points = np.array([point1, point2, shifted_point2, shifted_point1])
    return polygon_points

def check_line_color_in_rectangle(canvas, rect, line_color=170):
    """
    Check if the rectangle contains any pixel with the line color.

    :param canvas: 2D or 3D NumPy array representing the canvas (e.g., image)
    :param rect: tuple (x_min, y_min, x_max, y_max) defining the rectangle
    :param line_color: The color of the line to check (e.g., integer for grayscale or tuple for RGB)
    :return: True if the rectangle contains the line color, False otherwise
    """
    x_min, y_min, x_max, y_max = rect

    # Extract the rectangle area from the canvas
    rect_area = canvas[y_min:y_max+1, x_min:x_max+1]

    # Check if the line color is in the rectangle
    if len(canvas.shape) == 2:  # Grayscale image
        return np.any(rect_area == line_color)
    elif len(canvas.shape) == 3:  # RGB image
        return np.any(np.all(rect_area == line_color, axis=-1))
    else:
        raise ValueError("Unsupported canvas format. Must be 2D or 3D (grayscale or RGB).")

LF = 3.925 ### rear to front
LB = 1.025 ### rear to back, i.e., rear_hang
class Vehicle:
    def __init__(self, wb, fh, rh, width):
        self.wb = wb #3  # wheelbase
        self.fh = fh #0.925  # front hang length
        self.rh = rh #1.025  # rear hang length
        self.width = width #2 ##2.229  # width ##### maybe we should reduce it

    def create_polygon(self, x, y, theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        #### four points of the rectangle ### counterclockwise
        points = np.array([
            [-self.rh, -self.width/2, 1],
            [self.fh + self.wb, -self.width/2, 1],
            [self.fh + self.wb, self.width/2, 1],
            [-self.rh, self.width/2, 1],
        ]).dot(np.array([
            [cos_theta, -sin_theta, x],
            [sin_theta, cos_theta, y],
            [0, 0, 1]
        ]).transpose())
        return points[:, 0:2]
    
    def create_polygon_vehicle(self, x, y, theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        #### four points of the rectangle ### counterclockwise
        points = np.array([
            [-self.rh + 0.3, -self.width/2, 1],
            [self.fh + self.wb - 0.3, -self.width/2, 1],
            [self.fh + self.wb, -self.width/2 + 0.2, 1],
            [self.fh + self.wb,  self.width/2 - 0.2, 1],
            [self.fh + self.wb - 0.3,  self.width/2, 1],
            [-self.rh + 0.3, self.width/2, 1],
            [-self.rh,  self.width/2 - 0.2, 1],
            [-self.rh, -self.width/2 + 0.2, 1],
        ]).dot(np.array([
            [cos_theta, -sin_theta, x],
            [sin_theta, cos_theta, y],
            [0, 0, 1]
        ]).transpose())
        return points[:, 0:2]
    
    def create_polygon_target(self, x, y, theta):
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        #### four points of the rectangle ### counterclockwise
        points = np.array([
            [-self.rh-0.2, -2.3/2, 1],
            [self.fh + self.wb, -2.3/2, 1],
            [self.fh + self.wb, 2.3/2, 1],
            [-self.rh-0.2, 2.3/2, 1],
            [-self.rh-0.2, -2.3/2, 1],
        ]).dot(np.array([
            [cos_theta, -sin_theta, x],
            [sin_theta, cos_theta, y],
            [0, 0, 1]
        ]).transpose())
        return points[:, 0:2]    

        
vehicle_x_min = -1.1
vehicle_x_max = 3.925
vehicle_y_min = -1.1
vehicle_y_max = 1.1 
pixel_to_meter_ratio = 0.025
meter_to_pixel = lambda meters: int(meters / pixel_to_meter_ratio)
crop_l = 0.3 ##0.3m
crop_w = 0.2 ##0.2m
ego_x_px = 800
ego_y_px = 800
rear_hang = 1.025
rect_with_corner_cropped = np.array([
    [meter_to_pixel(-rear_hang + crop_l)+ego_x_px, meter_to_pixel(-1)+ego_y_px],     # bottom edge, left (after cropping left bottom corner)
    [meter_to_pixel(vehicle_x_max - crop_l)+ego_x_px, meter_to_pixel(-1)+ego_y_px],  # bottom edge, right (after cropping right bottom corner)
    [meter_to_pixel(vehicle_x_max)+ego_x_px, meter_to_pixel(-1 + crop_w)+ego_y_px],  # right edge, bottom (after cropping right bottom corner)
    [meter_to_pixel(vehicle_x_max)+ego_x_px,  meter_to_pixel(1 - crop_w)+ego_y_px],  # right edge, top (after cropping right top corner)
    [meter_to_pixel(vehicle_x_max - crop_l)+ego_x_px,  meter_to_pixel(1)+ego_y_px],  # top edge, right (after cropping right top corner)
    [meter_to_pixel(-rear_hang + crop_l)+ego_x_px, meter_to_pixel(1)+ego_y_px],      # top edge, left (after cropping left top corner)
    [meter_to_pixel(-rear_hang)+ego_x_px,  meter_to_pixel(1 - crop_w)+ego_y_px],     # left edge, top (after cropping left top corner)
    [meter_to_pixel(-rear_hang)+ego_x_px, meter_to_pixel(-1 + crop_w)+ego_y_px]      # left edge, bottom (after cropping left bottom corner)
])

def normalize_angle(angle):
    """Normalize angle to [-pi, pi]."""
    return np.float32((angle + np.pi) % (2 * np.pi) - np.pi) ### it is float64, we should reduce to 32 bits

        
def load_json_feature(filename, dilation=0.1, interp_dist=0.1):
    with open(filename, 'r') as file:
        # data = json.load(file)
        # ego_info = data['Frames']['0']["PlanningRequest"]["m_startPosture"]["m_pose"] ### x,y, theta
        # target_info = data['Frames']['0']["PlanningRequest"]["m_targetArea"]["m_targetPosture"]["m_pose"]
        # obstacles = []
        # for ele in data['Frames']['0']["NfmAggregatedPolygonObjects"]: ### list of dicts
        #     try:
        #         list_dict = ele["nfmPolygonObjectNodes"]
        #         assert len(list_dict) >= 2, "nfmPolygonObjectNodes number is less than 2"
        #         tmp = []
        #         for kk in list_dict:
        #             tmp.append([kk["m_x"], kk["m_y"]])
        #         obstacles.append(tmp) ### each element contains all the vertices of one polygon boundary
        #     except:
        #         print('{} does not have obstacles'.format(filename)) 
        
        data = json.load(file)
        try:
            nfm_origin = data['Frames']['0']["m_nfmOrigin"]
        except:
            nfm_origin = [0, 0] 
        try:       
            m_pathOrigin = data['Frames']['0']["PlanningRequest"]["m_origin"]
        except:
            m_pathOrigin = [0,0]    
            
        ego_info = data['Frames']['0']["PlanningRequest"]["m_startPosture"]["m_pose"] ### x,y, theta
        ego_info = [ego_info[0]+m_pathOrigin[0]-nfm_origin[0],ego_info[1]+m_pathOrigin[1]-nfm_origin[1],ego_info[2]]
        try:
            target_info = data['Frames']['0']["PlanningRequest"]["m_targetArea"]["m_targetPosture"]["m_pose"]
        except:
            target_info = data['Frames']['0']["PlanningRequest"]["m_targetAreas"]["m_targetPosture"][0]["m_pose"]  
        target_info = [target_info[0]+m_pathOrigin[0]-nfm_origin[0],target_info[1]+m_pathOrigin[1]-nfm_origin[1],target_info[2]]    
                    
        obstacles = []
        trans_matrix = np.array([[np.cos(target_info[2]), np.sin(target_info[2]), -target_info[0]*np.cos(target_info[2])-target_info[1]*np.sin(target_info[2])],
                            [-np.sin(target_info[2]), np.cos(target_info[2]), target_info[0]*np.sin(target_info[2])-target_info[1]*np.cos(target_info[2])],
                            [0, 0, 1]], dtype=np.float32) 
        for ele in data['Frames']['0']["NfmAggregatedPolygonObjects"]: ### list of dicts
            try: 
                list_dict = ele["nfmPolygonObjectNodes"]
                assert len(list_dict) >= 2, "nfmPolygonObjectNodes number is less than 2"
                tmp = []
                last_kk_x = last_kk_y = 0
                for i, kk in enumerate(list_dict):
                    current_kk_x = kk["m_x"]
                    current_kk_y = kk["m_y"]
                    if i == 0:
                        last_kk_x = current_kk_x
                        last_kk_y = current_kk_y
                    
                    # Check if obstacle points are spaced out more than 0.1m and interpolate
                    dist = np.sqrt((current_kk_x - last_kk_x)**2 + (current_kk_y - last_kk_y)**2)
                    if dist > interp_dist:
                        num_points = int(dist // interp_dist)
                        x_values = np.linspace(last_kk_x, current_kk_x, num_points + 2)[1:-1]
                        y_values = np.linspace(last_kk_y, current_kk_y, num_points + 2)[1:-1]
                        for x, y in zip(x_values, y_values):
                            tmp.append([x, y])

                    tmp.append([current_kk_x, current_kk_y])
                    last_kk_x = current_kk_x
                    last_kk_y = current_kk_y

                ##### filter the perception error 
                new_points = np.transpose(tmp) 
                new_points = np.vstack([new_points, [1]*new_points.shape[1]])
                result = np.transpose(np.matmul(trans_matrix, new_points)[0:2,:]) ##n*2 dimension 
                if np.sum((vehicle_x_min <= result[:,0]) & (result[:,0] <= vehicle_x_max) & (result[:,1] >= vehicle_y_min) & (result[:,1] <= vehicle_y_max)) > 0:
                    pass #print('This polyline intersects with target, hence filter it out, total vertices: ', len(tmp))
                else:    
                    obstacles.append(tmp) ### each element contains all the vertices of one polygon boundary
            except:
                pass
                print('{} does not have obstacles'.format(filename))   
                    
        flat_list = [item for sublist in obstacles for item in sublist]           
    ##### remove obstacle points within the target spot
    #### can be used for vectorized representation
    draw_boundary = []
    # trans_matrix = np.array([[np.cos(target_info[2]), np.sin(target_info[2]), -target_info[0]*np.cos(target_info[2])-target_info[1]*np.sin(target_info[2])],
    #                         [-np.sin(target_info[2]), np.cos(target_info[2]), target_info[0]*np.sin(target_info[2])-target_info[1]*np.cos(target_info[2])],
    #                         [0, 0, 1]]) 
    for points in obstacles:
        new_points = np.transpose(points)  
        new_points = np.vstack([new_points, [1]*new_points.shape[1]])
        
        result = np.transpose(np.matmul(trans_matrix, new_points)[0:2,:]) ##n*2 dimension 
        
        if np.sum((vehicle_x_min <= result[:,0]) & (result[:,0] <= vehicle_x_max) & (result[:,1] >= vehicle_y_min) & (result[:,1] <= vehicle_y_max)) > 0:
            pass #print('Perception error.... obstacle point in target area, ignore this point list')
        else:
            ##### we dilate the obstacles boundary and fix them based the target spot view
            for i in range(len(result)-1):
                points_in_target = generate_shifted_polygon(result[i], result[i+1], shift_magnitude=dilation) 
                tmp = []
                for edge in points_in_target:
                    x_world = target_info[0] + edge[0]*np.cos(target_info[2]) - edge[1]*np.sin(target_info[2])
                    y_world = target_info[1] + edge[0]*np.sin(target_info[2]) + edge[1]*np.cos(target_info[2])
                    tmp.append([x_world, y_world])
                draw_boundary.append(tmp) ### N*4*2  
    return ego_info, target_info, draw_boundary, obstacles, np.array(flat_list, dtype=np.float32)


def load_json_label(filename, interval=0.01, feature_path=None):
    if feature_path is not None:
        with open(feature_path, 'r') as file:
            data = json.load(file)
            target_info = data['Frames']['0']["PlanningRequest"]["m_targetArea"]["m_targetPosture"]["m_pose"]
    with open(filename, 'r') as file:
        data = json.load(file)
        mydata = data['Frames']['0']["PlanningResult"]["m_pathPlanningResult"]["m_pathPoints"]
        #print('Add target info as well')
        # try:
        #     mydata.append([target_info[0], target_info[1], target_info[2], 0])
        # except:
        #     print('No target info here...')    
        # print(type(mydata))
        # import pdb; pdb.set_trace()
        ### list of lists
        if data['Frames']['0']["PlanningResult"]["m_pathPlanningResult"]["m_success"]: ##.lower() == 'true'
            flag = True 
            mydata_interpolate = interpolate_path(mydata, fixed_interval=interval)  ###  
        else:
            flag = False 
            mydata_interpolate = mydata 
        
    return mydata_interpolate, flag  

def world_to_ego(point, ego_pos, ego_heading):
    """Convert a point from world to ego coordinate system."""
    dx, dy = np.array(point) - np.array(ego_pos)
    ### normalize angle to -pi to pi 
    ego_heading = np.arctan2(np.sin(ego_heading), np.cos(ego_heading))
    theta = - ego_heading
    x_ego = dx * np.cos(theta) - dy * np.sin(theta)
    y_ego = dx * np.sin(theta) + dy * np.cos(theta)
    return np.array([x_ego, y_ego])  

def transform_to_global(node, pos):
    x0, y0, yaw0 = pos
    x_rel = node.x
    y_rel = node.y
    yaw_rel = node.yaw

    cos_yaw = np.cos(yaw0)
    sin_yaw = np.sin(yaw0)

    x_global = x0 + x_rel * cos_yaw - y_rel * sin_yaw
    y_global = y0 + x_rel * sin_yaw + y_rel * cos_yaw
    yaw_global = yaw_rel + yaw0

    return x_global, y_global, yaw_global

def world_to_ego_array(points, ego_pos, ego_heading):
    """
    Convert multiple points from the world coordinate system to the ego coordinate system.
    
    Args:
        points (np.ndarray): Array of points in world coordinates, shape (N, 2) or (N, 3),
                             where N is the number of points. If shape (N, 3), the last column is theta.
        ego_pos (list or np.ndarray): Ego position in world coordinates [x, y].
        ego_heading (float): Ego heading angle in radians.
        
    Returns:
        np.ndarray: Transformed points in the ego coordinate system, shape (N, 2) or (N, 3).
    """
    # Convert inputs to numpy arrays for vectorized operations
    points = np.asarray(points)  # Shape (N, 2) or (N, 3)
    ego_pos = np.asarray(ego_pos)  # Shape (2,)
    
    # Check if points have theta values
    if points.shape[1] == 3:
        # Extract x, y, and theta
        x_points = points[:, 0]
        y_points = points[:, 1]
        theta_points = points[:, 2]
        # Combine x and y into a single array
        points_2d = np.column_stack((x_points, y_points))
    else:
        # No theta values, just use x and y
        points_2d = points

    # Translate points to the ego position
    translated_points_2d = points_2d - ego_pos  # Shape (N, 2)
    
    # Normalize ego heading angle to [-pi, pi]
    ego_heading = np.arctan2(np.sin(ego_heading), np.cos(ego_heading))
    
    # Create the rotation matrix for -ego_heading
    cos_theta = np.cos(-ego_heading)
    sin_theta = np.sin(-ego_heading)
    rotation_matrix = np.array([[cos_theta, -sin_theta], [sin_theta, cos_theta]])  # Shape (2, 2)
    
    # Apply the rotation to all translated points
    ego_points = translated_points_2d @ rotation_matrix.T  # Shape (N, 2)
    
    # If theta values were provided, adjust the theta values to the ego coordinate system
    if points.shape[1] == 3:
        # Adjust the theta values to the ego coordinate system
        ego_theta = theta_points - ego_heading
        # Combine the transformed points with the adjusted theta
        ego_points = np.column_stack((ego_points, ego_theta))  # Shape (N, 3)
    
    return ego_points  # Return transformed points with the same shape as input
        
def bev_generation(ego_info, target_info, obstacles, fake_boundary=None):
    ###########   wheelbase, front_hang, rear_hang, width
    vehicle = Vehicle( 3,       0.925,      1.025,   2.0)
    #### Parameters
    pixel_to_meter_ratio = 0.025 #0.05 # 0.025  # 1 pixel = 0.025 meters
    crop_width_m = 20            # Cropped image width in meters
    crop_height_m = 20           # Cropped image height in meters
    full_image_width_m = 40
    full_image_height_m = 40
    #### Cropped image dimensions in pixels
    crop_width_px = int(crop_width_m / pixel_to_meter_ratio)   # 800 pixels
    crop_height_px = int(crop_height_m / pixel_to_meter_ratio)  # 800 pixels
    # Full image size
    full_image_width_px = int(full_image_width_m / pixel_to_meter_ratio) # 1600 pixels
    full_image_height_px = int(full_image_height_m / pixel_to_meter_ratio) # 1600 pixels
    
    # Create a blank grayscale image (uint8: values 0 to 255)
    full_image = np.full((full_image_height_px, full_image_width_px), 0, dtype=np.uint8)  # black background

    # Ego vehicle's center in pixels
    ego_x_px = full_image_width_px // 2 
    ego_y_px = full_image_height_px // 2
    
    # Conversion function from meters to pixels
    meter_to_pixel = lambda meters: int(meters / pixel_to_meter_ratio)

    ### obstacles 
    # print(np.array(obstacles).shape)
    if obstacles:
        assert np.array(obstacles).shape[1:] == (4, 2) ## 'should be in the format as: N,4,2' ##    
    for polygon in obstacles:
        ### each row contains a polygon
        four_points = []
        for ele in polygon:
            point_in_ego = world_to_ego(ele, ego_info[0:2], ego_info[2]) #self._world_to_ego(ele)
            four_points.append([meter_to_pixel(point_in_ego[0])+ego_x_px, -meter_to_pixel(point_in_ego[1])+ego_y_px])
        four_points = np.array(four_points).reshape((-1,1,2))
        cv2.fillPoly(full_image, [four_points], color=170)
        
    ### target
    target_relative = world_to_ego(target_info[0:2], ego_info[0:2], ego_info[2])
    goal_x, goal_y = target_relative[0], target_relative[1]
    if isinstance(goal_x, list):
        goal_x = goal_x[0]
        goal_y = goal_y[0]

    # temp = vehicle.create_polygon_target(goal_x, goal_y, target_info[2]-ego_info[2])
    # target_points = []
    # for ele in temp[0:4]:
    #     target_points.append([meter_to_pixel(ele[0])+ego_x_px, -meter_to_pixel(ele[1])+ego_y_px])
    # target_points = np.array(target_points).reshape((-1,1,2))    
    # cv2.fillPoly(full_image, [target_points], color=0) ### use fillPoly as target is not aligned with axis
    
    temp = vehicle.create_polygon_vehicle(goal_x, goal_y, target_info[2]-ego_info[2])
    target_points = []
    for ele in temp[0:8]:
        target_points.append([meter_to_pixel(ele[0])+ego_x_px, -meter_to_pixel(ele[1])+ego_y_px])
    target_points = np.array(target_points).reshape((-1,1,2))    
    cv2.fillPoly(full_image, [target_points], color=255) ### use fillPoly as target is not aligned with axis
    cv2.circle(full_image, center=(meter_to_pixel(goal_x)+ego_x_px, -meter_to_pixel(goal_y)+ego_y_px), radius=10, color=75, thickness=-1)

    if fake_boundary:
        four_points = []
        for ele in fake_boundary:
            point_in_ego = world_to_ego(ele, ego_info[0:2], ego_info[2]) #self._world_to_ego(ele)
            four_points.append([meter_to_pixel(point_in_ego[0])+ego_x_px, -meter_to_pixel(point_in_ego[1])+ego_y_px])
        four_points = np.array(four_points).reshape((-1,1,2))
        cv2.fillPoly(full_image, [four_points], color=255) ### able to collide  
        
    # rect = (meter_to_pixel(-LB)+ego_x_px, meter_to_pixel(-1)+ego_y_px, 
    #             meter_to_pixel(LF)+ego_x_px, meter_to_pixel(1)+ego_y_px)
    # collision1 = check_line_color_in_rectangle(full_image, rect, line_color=170)
    collision = check_polygon_contains_other_color(full_image, rect_with_corner_cropped, 75, target_color=170)

    if steps == 1:
        total_time = 3  
        dt = 1.0       
        velocity_samples = [3.0]
        delta_degrees = [-30, 0, 30]  
        delta_samples = np.deg2rad(delta_degrees)

        actual_vehicle_state = [0,0,0]
        vehicle_state_init = [goal_x,goal_y, target_info[2]-ego_info[2]]
        generator = TrajectoryTreeGenerator(dt=dt, collision_check_steps=20, vehicle_state_init=vehicle_state_init, 
                                            check_polygon=True, full_image=full_image)
        generator.generate(total_time, velocity_samples, delta_samples)
        
        max_depth = max(node.depth for node in generator.all_nodes)
        safe_nodes = len(generator.all_nodes)
        print(f"Generated {safe_nodes} safe nodes after pruning")
        print(f"Max depth: {max_depth}")
        # plot_trajectory_tree(generator, generator.all_nodes, max_depth, actual_vehicle_state)
    else:
        dt = 1.0       
        vehicle_state_init = [goal_x,goal_y, target_info[2]-ego_info[2]]
        generator = TrajectoryTreeGenerator(dt=dt, collision_check_steps=20, vehicle_state_init=vehicle_state_init, 
                                            check_polygon=True, full_image=full_image)

    polygon_int = np.round(rect_with_corner_cropped).astype(np.int32).reshape((-1, 1, 2))
    cv2.fillPoly(full_image, [polygon_int], 75)
    cv2.circle(full_image, center=(ego_x_px, ego_y_px), radius=10, color=255, thickness=-1)
    
    
    # Define the cropping region (centered on the ego vehicle)
    crop_left = ego_x_px - crop_width_px // 2
    crop_upper = ego_y_px - crop_height_px // 2
    crop_right = ego_x_px + crop_width_px // 2
    crop_lower = ego_y_px + crop_height_px // 2
 
    cropped_image = full_image[crop_upper:crop_lower, crop_left:crop_right]
    cropped_image_resized = cv2.resize(cropped_image, (400,400), interpolation=cv2.INTER_NEAREST)   
    
    return cropped_image_resized, collision, generator

import scipy.signal
def compute_driving_commands(path, L=3.0, dt=0.01):
    """
    Extracts velocity and steering angle from a given path (x, y, theta, kappa).
    """
    x, y, theta, kappa = path[:,0], path[:,1], path[:,2], path[:,3]

    # Compute displacement-based velocity
    dx = np.diff(x, prepend=x[0])
    dy = np.diff(y, prepend=y[0])
    v = np.sqrt(dx**2 + dy**2) / dt

    # Determine direction (forward or reverse)
    direction = np.sign(np.cos(theta[:-1]) * dx[:-1] + np.sin(theta[:-1]) * dy[:-1])
    v *= np.append(direction, direction[-1])  # Apply direction correction

    # Compute acceleration
    a = np.diff(v, prepend=v[0]) / dt

    # Compute steering angle
    delta = np.arctan(kappa * L)

    # # Smooth velocity & steering
    # v = scipy.signal.savgol_filter(v, window_length=7, polyorder=3)
    # delta = scipy.signal.savgol_filter(delta, window_length=7, polyorder=3)

    return v, delta


def deconstruct_path(x, y, theta, delta_action_space, max_delta_delta, horizon, L=3.0, dt=0.1):
    """
    Deconstructs the path into velocity and steering commands.
    """
    dx = np.diff(x)
    dy = np.diff(y)
    v = np.sqrt(dx**2 + dy**2) / dt

    # Determine direction (forward or reverse)
    direction = np.sign(np.cos(theta[:-1]) * dx + np.sin(theta[:-1]) * dy)
    v *= direction
    # Discretize
    v = 10 * np.sign(v + 1e-8)

    # Compute steering angle
    x_now = x[0]
    y_now = y[0]
    theta_now = theta[0]
    delta = []
    # x_pot = []
    # y_pot = []
    # x_sel = []
    # y_sel = []
    for i in range(len(v)):
        # Get direction
        v_sign_now = np.sign(v[i])
        theta_sign_now = 1 if v_sign_now > 0 else -1

        if i < len(v) - horizon:
            # Find best delta
            # Check all potential positions within (limited) action space
            if np.sign(v[i]) * np.sign(v[i-1]) == 1 and i > 0:    # i is not a turning point --> limit delta steering angle
                delta_action_space_now = [d for d in delta_action_space if delta[-1]-max_delta_delta <= d <= delta[-1]+max_delta_delta]
            else:
                delta_action_space_now = delta_action_space
            delta_action_distances = []
            for delta_now_pot in delta_action_space_now:
                theta_next_pot = theta_now + theta_sign_now * (np.abs(v[i]) / L) * np.tan(delta_now_pot) * dt * horizon
                x_next2_pot = x_now + v[i] * np.cos(theta_now) * dt + v[i+1] * np.cos(theta_next_pot) * dt * horizon
                y_next2_pot = y_now + v[i] * np.sin(theta_now) * dt + v[i+1] * np.sin(theta_next_pot) * dt * horizon
                distance = np.sqrt((y_next2_pot - y[i+1+horizon])**2 + (x_next2_pot - x[i+1+horizon])**2)
                # x_pot.append(x_next2_pot)
                # y_pot.append(y_next2_pot)
                delta_action_distances.append(distance)

            delta_now = delta_action_space_now[np.argmin(delta_action_distances)]
            delta.append(delta_now)

        else:
            # Use previous delta
            delta.append(delta[-1])

        # Update states
        x_now += v[i] * np.cos(theta_now) * dt
        y_now += v[i] * np.sin(theta_now) * dt
        theta_now = theta_now + theta_sign_now * (np.abs(v[i]) / L) * np.tan(delta_now) * dt
        # x_sel.append(x_now)
        # y_sel.append(y_now)
    delta = np.array(delta)

    return v, delta #, np.stack((x_pot, y_pot), axis=1), np.stack((x_sel, y_sel), axis=1)

def deconstruct_path_non_adaptive(x, y, theta, delta_action_space, L=3.0, dt=0.1):
    """
    Deconstructs the path into velocity and steering commands.
    """
    dx = np.diff(x)
    dy = np.diff(y)
    v = np.sqrt(dx**2 + dy**2) / dt

    
    # Determine direction (forward or reverse)
    direction = np.sign(np.cos(theta[:-1]) * dx + np.sin(theta[:-1]) * dy)
    v *= direction
    # Discretize
    v = 1 * np.sign(v + 1e-8) ### to cover 0 case
    
    # print('velocity: ', v)

    # Compute steering angle
    delta = np.arctan((np.diff(theta)) / (v * dt) * L)
    
    # delta = np.arctan2((np.diff(theta))*L, (v * dt)) 
    # #print('np.arctan: ', np.degrees(delta))
    # delta_deg = np.degrees(delta)
    # delta_deg = np.where(delta_deg > 90, delta_deg - 180, delta_deg)
    # delta_deg = np.where(delta_deg < -90, delta_deg + 180, delta_deg) 
    # delta = np.radians(delta_deg)
    
    # # Discretize
    for i in range(delta.shape[0]):
        delta[i] = delta_action_space[np.argmin(np.abs(delta_action_space - delta[i]))]

    return v, delta
 
def reconstruct_path(x0, y0, theta0, v, delta, L=3.0, dt=0.1):
    """
    Reconstructs the path using the extracted velocity and steering commands.
    """
    x, y, theta = [x0], [y0], [theta0]
    for i in range(len(v)):
        # Handle reverse driving (flip orientation)
        v_sign = np.sign(v[i])
        theta_sign = 1 if v_sign > 0 else -1  # Reverse affects heading change

        # Kinematic update
        x_next = x[-1] + v[i] * np.cos(theta[-1]) * dt
        y_next = y[-1] + v[i] * np.sin(theta[-1]) * dt
        theta_next = theta[-1] + theta_sign * (np.abs(v[i]) / L) * np.tan(delta[i]) * dt
        # theta_next = theta[-1] + (v[i] / L) * np.tan(delta[i]) * dt

        x.append(x_next)
        y.append(y_next)
        theta.append(theta_next)

    return np.array(x), np.array(y), np.array(theta)

def backpropogate_path(np_arr, delta_action_space, max_delta_delta, horizon):    
    paths = []
    # v, delta = deconstruct_path(np_arr[:,0], np_arr[:,1], np_arr[:,2], delta_action_space, max_delta_delta, horizon, L=3.0, dt=0.01) ## compute_driving_commands(np_arr, L=3.0, dt=0.01)
    v, delta = deconstruct_path_non_adaptive(np_arr[:,0], np_arr[:,1], np_arr[:,2], delta_action_space, L=3.0, dt=0.1)
    x_recon, y_recon, theta_recon = reconstruct_path(np_arr[0,0], np_arr[0,1], np_arr[0,2], v, delta)

    for x, y, theta in zip(x_recon, y_recon, theta_recon):
        paths.append([x,y, theta]) 
    return paths, v, delta 


def plot_curve(ego, target, obstacles, path_data, delta_action_space): ##, original_path
    ###########   wheelbase, front_hang, rear_hang, width
    vehicle = Vehicle( 3,      0.925,      1.025,   2.0)
    
    plt.cla()
    plt.xlim(-20, 20) #### 40m*30m
    plt.ylim(-15, 15)
    plt.gca().set_aspect('equal')
    ### Plot ego vehicle at the center
    plt.plot(0, 0, 'bo', markersize=10, label="Ego Vehicle (Center)")
    temp = vehicle.create_polygon(0, 0, 0)
    plt.plot(temp[:, 0], temp[:, 1], linestyle='--', linewidth = 0.4, color = 'green')
    ### target
    target_relative = world_to_ego(target[0:2], ego[0:2], ego[2]) ### convert x,y from global to ego coordinate system
    plt.plot(target_relative[0], target_relative[1], 'ro', markersize=10, label="Target Position")
    temp = vehicle.create_polygon(target_relative[0], target_relative[1], target[2]-ego[2])
    plt.plot(temp[:, 0], temp[:, 1], linestyle='--', linewidth = 0.6, color = 'red')
    plt.fill(temp[:, 0], temp[:, 1], color='red', alpha=0.02)
    ### Plot obstacles in ego coordinates
    ###### Use the draw boundary
    for polygon in obstacles:
        ### each row contains a polygon
        four_points = []
        for ele in polygon:
            point_in_ego = world_to_ego(ele, ego[0:2], ego[2]) #self._world_to_ego(ele)
            four_points.append(point_in_ego)
        four_points = np.array(four_points) 
        plt.fill(four_points[:, 0], four_points[:, 1], color='skyblue', alpha=0.1) 
        
    ### the list of lists element contains [x,y, phi, kappa]
    np_arr = np.array(path_data) 
    covert_x = []
    covert_y = []
    for i in range(len(np_arr)): 
        point = world_to_ego([np_arr[i,0], np_arr[i,1]], ego[0:2], ego[2]) 
        covert_x.append(point[0])
        covert_y.append(point[1])
    plt.plot(covert_x, covert_y, label='GT Path-interpolated')  
    
    #### The following is used for checking forks in the path
    # plt.gca().xaxis.set_major_locator(MultipleLocator(0.01))
    # plt.gca().yaxis.set_major_locator(MultipleLocator(0.01))
    plt.show()


def transform_ego_to_target_frame(x_e, y_e, theta_e, x_t, y_t, theta_t):
    dx = x_e - x_t
    dy = y_e - y_t

    # Rotate ego position into target frame
    x_rel =  np.cos(-theta_t) * dx - np.sin(-theta_t) * dy
    y_rel =  np.sin(-theta_t) * dx + np.cos(-theta_t) * dy

    # Compute heading difference (ego w.r.t. target frame)
    theta_rel = np.float32((theta_e-theta_t + np.pi) % (2 * np.pi) - np.pi)

    return x_rel, y_rel, theta_rel


def plot_trajectory_tree(generator, all_nodes, max_depth, vehicle_state):
    plt.figure(figsize=(12, 10))
    colors = plt.cm.jet(np.linspace(0, 1, max_depth + 1))
    
    # 绘制障碍物
    for obs in generator.obstacles:
        cx, cy = obs['center']
        size = obs['size']
        plt.gca().add_patch(Rectangle(
            (cx-size/2, cy-size/2), size, size,
            facecolor='red', alpha=0.5
        ))
    
    # 绘制轨迹
    for node in all_nodes:
        if node.parent is not None:
            depth = node.depth
            color = colors[depth]
            
            # 获取轨迹点
            points = generator.get_trajectory_points(node.parent, node, 10)
            # 绘制轨迹线
            plt.plot(
                [p[0] for p in points],
                [p[1] for p in points],
                color=color, linewidth=1.5 - depth*0.1
            )
            # 在父节点位置添加标记
            plt.plot(node.parent.x, node.parent.y, 'ko', markersize=3)

        # 绘制箭头表示航向
        arrow_length = 0.5  # 箭头长度
        dx = arrow_length * np.cos(node.yaw)
        dy = arrow_length * np.sin(node.yaw)
        plt.arrow(node.x, node.y, dx, dy, head_width=0.2, head_length=0.2, fc='#800080', ec='#800080')

        # 计算并显示每个节点的 difference_distance
        target_states = [node.x, node.y, node.yaw]
        [distance, driving_distance] = difference_distance(target_states, vehicle_state)
        plt.text(node.x, node.y, f'{distance:.2f}', color='red', fontsize=8, ha='right')
        plt.text(node.x, node.y-0.3, f'{driving_distance:.2f}', color='blue', fontsize=8, ha='right')

        # # 计算并显示每个节点的 difference_distance
        # target_states = [node.x, node.y, node.yaw]
        # [distance, driving_distance] = difference_distance(target_states, vehicle_state_init)
        # plt.text(node.x, node.y-0.3, f'{distance:.2f}', color='blue', fontsize=8, ha='right')
    
    # 添加颜色条
    ax = plt.gca()
    sm = plt.cm.ScalarMappable(cmap=plt.cm.jet, norm=plt.Normalize(0, max_depth))
    sm.set_array([])
    fig = plt.gcf()
    cbar = fig.colorbar(sm, ax=ax, label='Time Level')
    cbar.set_ticks(np.arange(0, max_depth + 1))
    
    # 绘制起点
    plt.plot(all_nodes[0].x, all_nodes[0].y, 'go', markersize=10, label='Start')
    plt.plot(vehicle_state[0], vehicle_state[1], 'ro', markersize=10, label='Vehicle')
    plt.arrow(vehicle_state[0], vehicle_state[1], 0.5* np.cos(vehicle_state[2]), 0.5* np.sin(vehicle_state[2]), 
              head_width=0.2, head_length=0.2, fc="#F00000", ec="#FF0000")
    
    plt.xlabel('X (m)')
    plt.ylabel('Y (m)')
    plt.title('Trajectory Tree with Delta and V as Inputs')
    plt.grid(True)
    plt.axis('equal')
    plt.legend()
    
    # 调整图片大小和位置
    fig = plt.gcf()
    fig.set_size_inches(8, 6)  # 设置窗口大小为 8x6 英寸
    manager = plt.get_current_fig_manager()
    manager.window.wm_geometry("+800+100")

    plt.show()

    # plt.show(block=False)
    # time.sleep(4)
    # plt.close('all')


def difference_distance(target_states, vehicle_state):
    
    x, y, yaw = target_states[0], target_states[1], target_states[2]
    base_x, base_y, base_yaw = vehicle_state[0], vehicle_state[1], vehicle_state[2]

    rou = np.sqrt((x - base_x)**2 + (y - base_y)**2)
    theta_l  = np.atan2((y - base_y),(x - base_x))
    delta_theta = yaw - base_yaw

    distance_1 = rou * np.cos(theta_l) * (np.tan(theta_l) - np.tan(delta_theta/2))
    distance_2 = rou * np.sin(theta_l) * (1 - np.tan(delta_theta/2) / np.tan(theta_l))

    # 处理特殊情况
    if np.sin(theta_l) == 0:
        distance = distance_1
    elif np.cos(theta_l) == 0:
        distance = distance_2
    else:
        distance = (distance_1 + distance_2) / 2

    driving_distance =  rou * distance
    return [distance, driving_distance]

def get_energy(all_nodes, pos):
    energy = 0
    for node in all_nodes:
        if node.depth == 0:
            weight = 3
        elif node.depth < 3:
            weight = 1 * (0.7 ** node.depth)
        else:
            weight = 1 * (0.5 ** node.depth)
        energy += weight * parking_energy(pos[0], pos[1], pos[2], node.x, node.y, node.yaw)
    return energy


if __name__ == "__main__":
    
    parent_dir = "C:/RL/reward_hand_design_check/"

    # FEATURE_PATH = parent_dir+"features/"
    # LABEL_PATH = parent_dir+"labels/"
    # feature_files = os.listdir(FEATURE_PATH)
    # print('Total feature files: ', len(feature_files))
    # label_files = os.listdir(LABEL_PATH)
    # print('Total label files: ', len(label_files))
    # common_files = list(set(feature_files) & set(label_files))  
    # print('Files in common: ', len(common_files))
    

    FEATURE_PATH = parent_dir+"Data_hard/hard/"
    LABEL_PATH = parent_dir+"labels/"
    label_file_path = LABEL_PATH + "17132421470252371661.json"

    feature_files = os.listdir(FEATURE_PATH)
    print('Total feature files: ', len(feature_files))
    label_files = os.listdir(LABEL_PATH)
    print('Total label files: ', len(label_files))
    common_files = feature_files
    print('Files in common: ', len(common_files))
    

   
    for file in common_files: ## tqdm(common_files, desc="Processing files"):
        feature_file_path = FEATURE_PATH + file
        # label_file_path = LABEL_PATH + file
        
    
        ego_info, target_info, draw_boundary, obstacles, obstacles_global = load_json_feature(feature_file_path, dilation=0.05, interp_dist=0.1)
        interval = 0.08
        planned_path, success_or_not = load_json_label(label_file_path, interval=interval, feature_path=feature_file_path)
        
        L_m = 1.45  ### rear center to middle point
        target_middle_x = target_info[0] + L_m * np.cos(target_info[2])
        target_middle_y = target_info[1] + L_m * np.sin(target_info[2])
        
        long_rel, lateral_rel, theta_rel = transform_ego_to_target_frame(ego_info[0], ego_info[1], ego_info[2], target_info[0], target_info[1], target_info[2])           
        phase2 = False
        if long_rel < 0:
            print('\n\n\nThe starting position is behind the target which is not correct\n')
        else:    
            if lateral_rel * np.sign(theta_rel) >= 0 and abs(theta_rel) <= np.pi/2:
                print('\nThe starting pose is ready for parking without need further adjsutment!')
                phase2 = True
    
        print('\nNow visualize the path...')
        
        rewards = []
        distances = []
        angles = []
        steps = 0
        energys = []
        for pos in planned_path:
            print(steps)
            steps += 1

            
            if steps == 1:
                cropped_image_resized, collision, generator = bev_generation([pos[0], pos[1], pos[2]], target_info, draw_boundary)
                for node in generator.all_nodes:
                    node.x, node.y, node.yaw = transform_to_global(node, [pos[0], pos[1], pos[2]])
                    max_depth = max(node.depth for node in generator.all_nodes)
                    actual_vehicle_state = [pos[0], pos[1], pos[2]]
                
                energy = get_energy(generator.all_nodes, pos)
                plot_energy(generator.all_nodes, actual_vehicle_state)
                plot_trajectory_tree(generator, generator.all_nodes, max_depth, actual_vehicle_state)
                plot_energy(generator.all_nodes)
            else:
                cropped_image_resized, collision, _  = bev_generation([pos[0], pos[1], pos[2]], target_info, draw_boundary)
                energy = get_energy(generator.all_nodes, pos)


            
            # cv2.imshow('Parking simu', cropped_image_resized)
            # cv2.waitKey(10)
            
            ego_middle_x = pos[0] + L_m * np.cos(pos[2])
            ego_middle_y = pos[1] + L_m * np.sin(pos[2])
            dist_to_target = np.hypot(ego_middle_x - target_middle_x, ego_middle_y - target_middle_y)
            long_rel, lateral_rel, theta_rel = transform_ego_to_target_frame(pos[0], pos[1], pos[2], target_info[0], target_info[1], target_info[2]) 
            if phase2: ### ready to park
                reward = -0.1*(1*dist_to_target/15 + 0.5*( 1 - np.cos(theta_rel/2)))
            else: ### still need to adjust its pose 
                if long_rel * lateral_rel * np.sign(theta_rel) >= 0 and abs(theta_rel) <= np.pi/2:
                    print('after movement, the starting pose is ready for parking without need further adjsutment!')
                    # time.sleep(5)
                    phase2 = True 
                else:
                    ## use reward to lead the agent to adjust its pose 
                    reward = -(0.15+0.05*( 1 - np.cos(theta_rel/2)))  
            
            rewards.append(reward)
            distances.append(dist_to_target)
            angles.append(np.rad2deg(theta_rel))
            energys.append(energy)
                
        cv2.destroyAllWindows()


        save_nodes_to_json(generator.all_nodes, os.path.join('C:/RL/reward_hand_design_check/Data_hard/Energy_hard', file))
        # all_nodes = load_nodes_from_json(os.path.join('C:/RL/reward_hand_design_check/Data_hard/Energy_hard', file))
        # plot_energy(all_nodes, actual_vehicle_state)
        # plot_trajectory_tree(generator, generator.all_nodes, max_depth, actual_vehicle_state)
        
        steps = np.arange(len(rewards))
        ##### Plot
        fig, ax1 = plt.subplots(figsize=(10, 6))
        # Plot distance and angle on primary axis

        ax1.plot(steps, distances, label='Distance to Target', linestyle='-', color='tab:blue')
        ax1.plot(steps, angles, label='Theta Rel (deg)', linestyle='--', color='tab:orange')
        ax1.set_xlabel("Trajectory Step")
        ax1.set_ylabel("Distance / Angle")
        ax1.tick_params(axis='y')
        ax1.legend(loc='upper left')

        # Plot reward on secondary axis
        ax2 = ax1.twinx()
        ax2.plot(steps, rewards, label='Reward', color='tab:green', linewidth=2)
        # ax2.set_ylabel("Reward")
        # ax2.legend(loc='upper right')

        ax3 = ax1.twinx()
        ax3.plot(steps, energys, label='Energys', color='tab:red', linewidth=2)
        ax3.set_ylabel("Energy")
        ax3.legend(loc='upper right')

        plt.title("Reward, Distance, and Angle Along Trajectory")
        plt.grid(True)
        plt.tight_layout()
        # plt.show()